
import numpy as np
import cv2
import time
import threading
import socket
import struct

try:
    import NDIlib as ndi
    NDI_AVAILABLE = True
    print("✅ NDI library loaded")
except ImportError:
    NDI_AVAILABLE = False
    print("❌ NDI library not installed, cannot send NDI stream")

class ESP32AnimatorBridge:
    def __init__(self, width=1280, height=720, fps=30, 
                 udp_port=8000, stream_name="ESP32_Animator_NDI"):
        self.width = width
        self.height = height
        self.fps = fps
        self.frame_time = 1.0 / fps
        self.udp_port = udp_port
        self.stream_name = stream_name
        
        # Data buffer
        self.full_thermal_frame = np.zeros(768, dtype=np.float32)
        
        # Algorithm parameters
        self.ambient_temp = 23.0
        self.min_blob_area = 5
        
        # --- State machine core variables ---
        self.state = "WAITING" # Current state: WAITING, RECORDING, PLAYING
        self.last_state_change_time = time.time()
        self.wait_duration = 1.0 # Wait 1 second after animation playback
        self.record_duration = 3.0 # Record for 3 seconds
        self.playback_duration = 3.0 # Play for 3 seconds
        self.points_to_record = 5
        
        self.recorded_trajectory = [] # Store recorded trajectory points
        
        self.data_lock = threading.Lock()
        self.running = False
        
        # NDI related
        self.ndi_available = NDI_AVAILABLE
        self.ndi_send = None
        self.frame_bgra = np.zeros((height, width, 4), dtype=np.uint8)
        
        if self.ndi_available:
            if not ndi.initialize(): self.ndi_available = False
            else:
                ndi_send_settings = ndi.SendCreate()
                ndi_send_settings.ndi_name = self.stream_name
                self.ndi_send = ndi.send_create(ndi_send_settings)
                if self.ndi_send: print(f"✅ NDI sender created: {self.stream_name}")
                else: self.ndi_available = False

    def udp_server_loop(self):
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.bind(("0.0.0.0", self.udp_port))
            print(f"✅ UDP server started, listening on port: {self.udp_port}")
            while self.running:
                try:
                    data, addr = sock.recvfrom(1024)
                    if len(data) == 264:
                        header_format = '<i'
                        payload_format = '<64f'
                        start_index = struct.unpack_from(header_format, data, 0)[0]
                        temperatures = struct.unpack_from(payload_format, data, 4)
                        with self.data_lock:
                            if 0 <= start_index <= 704:
                                self.full_thermal_frame[start_index : start_index + 64] = temperatures
                except: pass

    def get_current_hotspot(self):
        """Calculates and returns the normalized coordinates (x,y) of the hottest spot from the current thermal map."""
        with self.data_lock:
            current_frame_data = self.full_thermal_frame.copy()
        temp_matrix = current_frame_data.reshape(24, 32)
        norm_matrix = cv2.normalize(temp_matrix, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        _, binary_image = cv2.threshold(norm_matrix, self.ambient_temp, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            if cv2.contourArea(largest_contour) > self.min_blob_area:
                M = cv2.moments(largest_contour)
                if M["m00"] != 0:
                    norm_x = M["m10"] / M["m00"] / 31.0 
                    norm_y = M["m01"] / M["m00"] / 23.0
                    return (norm_x, norm_y)
        return None

    def process_and_draw_frame(self):
        while self.running:
            current_time = time.time()
            elapsed_time = current_time - self.last_state_change_time
            frame = np.zeros((self.height, self.width, 3), dtype=np.uint8)

            # --- State machine logic ---
            if self.state == "WAITING":
                cv2.putText(frame, "Waiting for next cycle...", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
                if elapsed_time >= self.wait_duration:
                    self.state = "RECORDING"
                    self.last_state_change_time = current_time
                    self.recorded_trajectory = [] # Clear the previous trajectory
                    print("🔴 State change: WAITING -> RECORDING")
            
            elif self.state == "RECORDING":
                # During recording, record a point at regular intervals
                record_interval = self.record_duration / self.points_to_record
                num_recorded = len(self.recorded_trajectory)
                
                if num_recorded < self.points_to_record and elapsed_time >= num_recorded * record_interval:
                    hotspot = self.get_current_hotspot()
                    if hotspot:
                        self.recorded_trajectory.append(hotspot)
                        print(f"  -> Recorded point {len(self.recorded_trajectory)}/{self.points_to_record}: {hotspot}")
                
                cv2.putText(frame, f"Recording... {len(self.recorded_trajectory)}/{self.points_to_record} points", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
                
                if elapsed_time >= self.record_duration:
                    self.state = "PLAYING"
                    self.last_state_change_time = current_time
                    print("🟢 State change: RECORDING -> PLAYING")
            
            elif self.state == "PLAYING":
                if len(self.recorded_trajectory) < 2:
                    # If not enough points are recorded, skip playback
                    self.state = "WAITING"
                    self.last_state_change_time = current_time
                    print("🟡 Not enough points recorded, skipping playback.")
                else:
                    progress = min(elapsed_time / self.playback_duration, 1.0)
                    pixel_points = [(int(pt[0] * self.width), int(pt[1] * self.height)) for pt in self.recorded_trajectory]
                    
                    # --- Draw animation ---
                    total_segments = len(pixel_points) - 1
                    current_segment_float = progress * total_segments
                    segment_index = min(int(current_segment_float), total_segments - 1)
                    segment_progress = current_segment_float - segment_index
                    
                    start_point = pixel_points[segment_index]
                    end_point = pixel_points[segment_index + 1]
                    
                    dot_x = int(start_point[0] + (end_point[0] - start_point[0]) * segment_progress)
                    dot_y = int(start_point[1] + (end_point[1] - start_point[1]) * segment_progress)

                    cv2.circle(frame, (dot_x, dot_y), 12, (150, 150, 150), -1)
                    cv2.putText(frame, f"Playing animation... {progress:.2f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                
                if elapsed_time >= self.playback_duration:
                    self.state = "WAITING"
                    self.last_state_change_time = current_time
                    print("⏸️ State change: PLAYING -> WAITING")
            
            # --- NDI sending ---
            if self.ndi_available and self.ndi_send:
                cv2.cvtColor(frame, cv2.COLOR_BGR2BGRA, dst=self.frame_bgra)
                video_frame = ndi.VideoFrameV2()
                video_frame.data = self.frame_bgra
                video_frame.FourCC = ndi.FOURCC_VIDEO_TYPE_BGRA
                ndi.send_send_video_v2(self.ndi_send, video_frame)
                
            time.sleep(self.frame_time)

    def start(self):
        self.running = True
        udp_thread = threading.Thread(target=self.udp_server_loop)
        udp_thread.daemon = True
        udp_thread.start()
        render_thread = threading.Thread(target=self.process_and_draw_frame)
        render_thread.daemon = True
        render_thread.start()
        print("✅ All threads started")
        print("Press Ctrl+C to stop...")
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt: self.stop()

    def stop(self):
        self.running = False
        time.sleep(0.2)
        if self.ndi_available and self.ndi_send:
            ndi.send_destroy(self.ndi_send)
            ndi.destroy()
        print("\n✅ Program stopped")

if __name__ == "__main__":
    bridge = ESP32AnimatorBridge()
    bridge.start()