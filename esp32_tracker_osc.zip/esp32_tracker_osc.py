
import numpy as np
import cv2
import socket
import struct
import threading
import time
from pythonosc import udp_client

# ----------- [Configuration] -----------
UDP_LISTEN_PORT = 8000
TOUCHDESIGNER_IP = "127.0.0.1"
TOUCHDESIGNER_PORT = 9000
SMOOTHING_FACTOR = 0.15 # Smaller value = smoother movement
# ------------------------------------

class ThermalTracker:
    def __init__(self):
        self.full_thermal_frame = np.zeros(768, dtype=np.float32)
        self.data_lock = threading.Lock()
        self.running = False
        
        # Position variables
        self.detected_position = (0.5, 0.5) # Normalized coordinates (0-1)
        self.smoothed_position = (0.5, 0.5)
        
        # OSC Client
        self.osc_client = udp_client.SimpleUDPClient(TOUCHDESIGNER_IP, TOUCHDESIGNER_PORT)
        print(f"✅ OSC client configured, sending data to {TOUCHDESIGNER_IP}:{TOUCHDESIGNER_PORT}")

    def udp_server_loop(self):
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.bind(("0.0.0.0", UDP_LISTEN_PORT))
            print(f"✅ UDP server started, listening on port: {UDP_LISTEN_PORT}")
            while self.running:
                try:
                    data, _ = sock.recvfrom(1024)
                    if len(data) == 264:
                        start_index = struct.unpack_from('<i', data, 0)[0]
                        temperatures = struct.unpack_from('<64f', data, 4)
                        with self.data_lock:
                            if 0 <= start_index <= 704:
                                self.full_thermal_frame[start_index : start_index + 64] = temperatures
                except: pass

    def processing_loop(self):
        while self.running:
            with self.data_lock:
                current_frame_data = self.full_thermal_frame.copy()

            temp_matrix = current_frame_data.reshape(24, 32)
            norm_matrix = cv2.normalize(temp_matrix, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            _, binary_image = cv2.threshold(norm_matrix, 23.0, 255, cv2.THRESH_BINARY)
            contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            target_found = False
            if contours:
                largest_contour = max(contours, key=cv2.contourArea)
                if cv2.contourArea(largest_contour) > 5:
                    M = cv2.moments(largest_contour)
                    if M["m00"] != 0:
                        norm_x = M["m10"] / M["m00"] / 31.0 
                        norm_y = M["m01"] / M["m00"] / 23.0
                        self.detected_position = (norm_x, norm_y)
                        target_found = True
            
            # Smoothing algorithm
            dx = self.detected_position[0] - self.smoothed_position[0]
            dy = self.detected_position[1] - self.smoothed_position[1]
            new_smoothed_x = self.smoothed_position[0] + dx * SMOOTHING_FACTOR
            new_smoothed_y = self.smoothed_position[1] + dy * SMOOTHING_FACTOR
            self.smoothed_position = (new_smoothed_x, new_smoothed_y)
            
            # Send OSC message
            self.osc_client.send_message("/possum/position", [self.smoothed_position[0], self.smoothed_position[1]])
            
            if target_found:
                print(f"🎯 Target locked, smoothed coordinates: ({self.smoothed_position[0]:.2f}, {self.smoothed_position[1]:.2f}) -> OSC")
            
            time.sleep(1/30) # Control processing and sending frequency

    def start(self):
        self.running = True
        udp_thread = threading.Thread(target=self.udp_server_loop)
        udp_thread.daemon = True
        udp_thread.start()
        
        processing_thread = threading.Thread(target=self.processing_loop)
        processing_thread.daemon = True
        processing_thread.start()
        
        print("🚀 Real-time tracking started, press Ctrl+C to stop.")
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt: self.stop()

    def stop(self):
        print("\n⏹️  Stopping...")
        self.running = False
        time.sleep(0.5)
        print("✅ Program stopped")

if __name__ == "__main__":
    tracker = ThermalTracker()
    tracker.start()